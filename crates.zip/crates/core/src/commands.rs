//! The commands that can be run by the CLI.

pub mod backup;
pub mod cat;
pub mod check;
pub mod config;
pub mod copy;
pub mod dump;
pub mod forget;
pub mod init;
pub mod key;
pub mod merge;
pub mod prune;
pub mod repair;
pub mod repoinfo;
pub mod restore;
pub mod rewrite;
