//! `restore` subcommand

use derive_setters::Setters;
use log::{debug, error, info, trace, warn};
use smallvec::SmallVec;

use crate::{
    CancelToken, File, FileLister, ListAdapter, ListBuilder, ReadSource, WriteHandle, WriteSource,
    backend::{
        FileType, ReadBackend,
        decrypt::DecryptReadBackend,
        node::{Node, NodeType},
    },
    blob::{BlobLocation, BlobLocations},
    error::{ErrorKind, RusticError, RusticResult},
    repofile::packfile::PackId,
    repository::{IndexedFull, IndexedTree, Open, Repository},
};
use bytes::Bytes;
use dashmap::DashSet;
use itertools::Itertools;
use rayon::ThreadPoolBuilder;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::Path;
use std::{cmp::Ordering, collections::BTreeMap, path::PathBuf, sync::Mutex};

pub(crate) mod constants {
    /// The maximum number of reader threads to use for restoring.
    pub(crate) const MAX_READER_THREADS_NUM: usize = 20;
}

type Filenames = Vec<PathBuf>;
type RestoreInfo = BTreeMap<(PackId, BlobLocation), SmallVec<[FileLocation; 1]>>;

#[allow(clippy::struct_excessive_bools)]
#[cfg_attr(feature = "clap", derive(clap::Parser))]
#[derive(Debug, Clone, Copy, Default, Setters, Serialize, Deserialize)]
#[setters(into)]
#[non_exhaustive]
/// Options for the `restore` command
pub struct RestoreOptions {
    /// Remove all files/dirs in destination which are not contained in snapshot.
    ///
    /// # Warning
    ///
    /// * Use with care, maybe first try this with `--dry-run`?
    #[cfg_attr(feature = "clap", clap(long))]
    pub delete: bool,

    /// Use numeric ids instead of user/group when restoring uid/gui
    #[cfg_attr(feature = "clap", clap(long))]
    pub numeric_id: bool,

    /// Don't restore ownership (user/group)
    #[cfg_attr(feature = "clap", clap(long, conflicts_with = "numeric_id"))]
    pub no_ownership: bool,

    /// Do not scan file contents in the destination (only check hash if available).
    #[cfg_attr(feature = "clap", clap(long, conflicts_with = "verify_existing"))]
    pub no_compare: bool,

    /// Always read and verify existing files (don't trust correct modification time and file size)
    #[cfg_attr(feature = "clap", clap(long))]
    pub verify_existing: bool,
}

#[derive(Default, Debug, Clone, Copy)]
#[non_exhaustive]
/// Statistics for files or directories
pub struct FileDirStats {
    /// Number of files or directories to restore
    pub restore: u64,
    /// Number of files or directories which are unchanged (determined by date, but not verified)
    pub unchanged: u64,
    /// Number of files or directories which are verified and unchanged
    pub verified: u64,
    /// Number of files or directories which are modified
    pub modify: u64,
    /// Number of additional entries
    pub additional: u64,
}

#[derive(Default, Debug, Clone, Copy)]
#[non_exhaustive]
/// Restore statistics
pub struct RestoreStats {
    /// file statistics
    pub files: FileDirStats,
    /// directory statistics
    pub dirs: FileDirStats,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct HardlinkKey {
    device_id: u64,
    inode: u64,
}

/// Restore the repository to the given destination.
///
/// # Type Parameters
///
/// * `P` - The progress bar type
/// * `S` - The type of the indexed tree
///
/// # Arguments
///
/// * `file_infos` - The restore information
/// * `repo` - The repository to restore
/// * `opts` - The restore options
/// * `node_streamer` - The node streamer to use
/// * `dest` - The destination to restore to
///
/// # Errors
///
/// * If the restore failed.
pub(crate) fn restore_repository<S: IndexedTree>(
    file_infos: RestorePlan,
    repo: &Repository<S>,
    opts: RestoreOptions,
    node_streamer: impl Iterator<Item = RusticResult<(PathBuf, Node)>>,
    dest: &impl WriteSource,
    token: CancelToken,
) -> RusticResult<()> {
    token.check()?;
    repo.warm_up_wait(file_infos.to_packs().into_iter())?;

    token.check()?;
    dest.create_dir_all(Path::new(&file_infos.root))
        .map_err(|err| {
            RusticError::with_source(ErrorKind::Backend, "Failed to initialize restore.", err)
        })?; // *** create the root directory here.
    restore_contents(
        repo,
        dest,
        &file_infos.names,
        file_infos.file_lengths,
        file_infos.r,
        file_infos.restore_size,
        token.clone(),
    )?;

    token.check()?;
    let p = repo.progress_spinner("setting metadata...");
    restore_metadata(
        node_streamer,
        &file_infos.hardlink_candidates,
        opts,
        dest,
        token,
    )?;
    p.finish();

    Ok(())
}
/// Collect restore information, scan existing files, create needed dirs and remove superfluous files
///
/// # Type Parameters
///
/// * `R` - The type of the destination's `ReadSource`, walked via `src`.
/// * `S` - The type of the indexed tree.
///
/// # Arguments
///
/// * `repo` - The repository to restore.
/// * `opts` - The restore options.
/// * `node_streamer` - The node streamer to use.
/// * `src` - Lister over the existing entries at `dest`, used to diff against `node_streamer`.
/// * `dest` - The destination to restore to.
/// * `dry_run` - If true, don't actually restore anything, but only print out what would be done.
///
/// # Errors
///
/// * If a directory could not be created.
/// * If the restore information could not be collected.
#[allow(clippy::too_many_lines)]
pub(crate) fn collect_and_prepare<R, S>(
    repo: &Repository<S>,
    opts: RestoreOptions,
    mut node_streamer: impl Iterator<Item = RusticResult<(PathBuf, Node)>>,
    dest: &R,
    dest_path: &PathBuf,
    dry_run: bool,
    token: CancelToken,
) -> RusticResult<RestorePlan>
where
    R: WriteSource,
    S: IndexedFull,
{
    token.check()?;

    let p = repo.progress_spinner("collecting file information...");
    dest.create_dir_all(Path::new(dest_path)).map_err(|err| {
        RusticError::with_source(ErrorKind::Backend, "Failed to initialize restore.", err)
    })?; // *** create the root directory here.

    let mut stats = RestoreStats::default();
    let mut restore_infos = RestorePlan::default();
    let mut additional_existing = false;
    let skip_dirs = DashSet::<PathBuf>::new();
    let clean_path = |path: &Path| -> PathBuf {
        Path::new(
            path.to_string_lossy()
                .replace("\\", "/")
                .trim_start_matches("/")
                .trim_end_matches("/"),
        )
        .to_path_buf()
    };

    // Pulls the next entry out of `src`, skipping anything under a
    // directory we've already decided to skip (an "additional" dir we're
    // not descending into).
    let next_entry = |walker: &mut ListAdapter<'_, R>| -> Option<File> {
        walker
            .inspect(|r| {
                if let Err(err) = r {
                    error!("Error during collection of files: {err:?}");
                }
            })
            .find_map(|x| {
                if let Ok(ret) = x {
                    if !skip_dirs.iter().any(|d| {
                        let check_a = clean_path(&ret.path);
                        let check_b = clean_path(d.key());
                        check_a.starts_with(check_b)
                    }) {
                        // We need to strip the prefix from the path to avoid "additionals".
                        return Some(ret);
                    }
                }
                None
            })
    };

    let mut process_existing =
        |walker: &mut ListAdapter<'_, R>, entry: &File| -> RusticResult<Option<File>> {
            if clean_path(&entry.path) == clean_path(Path::new("/")) {
                // don't process the root dir which should be existing
                return Ok(next_entry(walker));
            }

            debug!("additional {}", entry.path.display());
            let is_dir = entry.is_dir();
            if is_dir {
                stats.dirs.additional += 1;
            } else {
                stats.files.additional += 1;
            }
            match (opts.delete, dry_run, is_dir) {
                (true, true, true) => {
                    info!(
                        "would have removed the additional dir: {}",
                        entry.path.display()
                    );
                }
                (true, true, false) => {
                    info!(
                        "would have removed the additional file: {}",
                        entry.path.display()
                    );
                }
                (true, false, true) => {
                    if let Err(err) = dest.remove_dir(&entry.path) {
                        error!("error removing {}: {err}", entry.path.display());
                    }
                }
                (true, false, false) => {
                    if let Err(err) = dest.remove_file(&entry.path) {
                        error!("error removing {}: {err}", entry.path.display());
                    }
                }
                (false, _, _) => {
                    additional_existing = true;
                }
            }

            // don't descend into extra dirs
            if is_dir {
                let _ = skip_dirs.insert(entry.path.clone());
            }
            Ok(next_entry(walker))
        };

    let mut process_node = |path: &PathBuf, node: &Node, exists: bool| -> RusticResult<_> {
        match node.node_type {
            NodeType::Dir => {
                if exists {
                    stats.dirs.modify += 1;
                    trace!("existing dir {}", path.display());
                } else {
                    stats.dirs.restore += 1;
                    debug!("to restore: {}", path.display());
                    if !dry_run {
                        dest.create_dir_all(path)
                            .map_err(|err| {
                                RusticError::with_source(
                                    ErrorKind::InputOutput,
                                    "Failed to create the directory `{path}`. Please check the path and try again.",
                                    err,
                                )
                                    .attach_context("path", path.display().to_string())
                            })?;
                    }
                }
            }
            NodeType::File => {
                if let Some(key) = hardlink_key(node) {
                    match restore_infos.hardlink_candidates.entry(key) {
                        std::collections::btree_map::Entry::Vacant(entry) => {
                            trace!("Adding hardlink candidate {}", path.display());
                            _ = entry.insert(path.clone());
                        }
                        std::collections::btree_map::Entry::Occupied(_) => return Ok(()), // this is a hardlink to an existing candidate, will be processed later while setting metadata
                    }
                }
                // collect blobs needed for restoring
                match (
                    exists,
                    restore_infos.add_file(
                        dest,
                        node,
                        path.clone(),
                        repo,
                        opts.verify_existing,
                        opts.no_compare,
                    )?,
                ) {
                    // Note that exists = false and Existing or Verified can happen if the file is changed between scanning the dir
                    // and calling add_file. So we don't care about exists but trust add_file here.
                    (_, AddFileResult::Existing) => {
                        stats.files.unchanged += 1;
                        trace!("identical file: {}", path.display());
                    }
                    (_, AddFileResult::Verified) => {
                        stats.files.verified += 1;
                        trace!("verified identical file: {}", path.display());
                    }
                    // TODO: The differentiation between files to modify and files to create could be done only by add_file
                    // Currently, add_file never returns Modify, but always New, so we differentiate based on exists
                    (true, AddFileResult::Modify) => {
                        stats.files.modify += 1;
                        debug!("to modify: {}", path.display());
                    }
                    (false, AddFileResult::Modify) => {
                        stats.files.restore += 1;
                        debug!("to restore: {}", path.display());
                    }
                }
            }
            _ => {} // nothing to do for symlink, device, etc.
        }
        Ok(())
    };

    let mut src = ListBuilder::new(dest)
        .with_root(dest_path)
        .build()
        .map_err(|err| {
            RusticError::with_source(
                ErrorKind::InputOutput,
                "Failed to create list adapter for destination.",
                err,
            )
        })?;

    let mut next_dst = next_entry(&mut src);
    let mut next_node = node_streamer.next().transpose()?;
    loop {
        // Check at the top of every iteration so we stop cleanly between
        // entries rather than mid-way through processing one.
        token.check()?;

        match (&next_dst, &next_node) {
            (None, None) => break,

            (Some(destination), None) => {
                next_dst = process_existing(&mut src, destination)?;
            }
            (Some(destination), Some((path, node))) => {
                let path = crate::join_force(dest_path, path);
                let path_a = clean_path(&destination.path);
                let path_b = clean_path(&path);
                trace!("comparing {:?} with {:?}", &path_a, &path_b);
                match path_a.cmp(&path_b) {
                    Ordering::Less => {
                        next_dst = process_existing(&mut src, destination)?;
                    }
                    Ordering::Equal => {
                        // process existing node
                        if (node.is_dir() && !destination.is_dir())
                            || (node.is_file() && !destination.is_file())
                            || node.is_special()
                        {
                            // if types do not match, first remove the existing file
                            next_dst = process_existing(&mut src, destination)?;
                        } else {
                            next_dst = next_entry(&mut src);
                        }
                        process_node(&path, node, true)?;
                        next_node = node_streamer.next().transpose()?;
                    }
                    Ordering::Greater => {
                        process_node(&path, node, false)?;
                        next_node = node_streamer.next().transpose()?;
                    }
                }
            }
            (None, Some((path, node))) => {
                let path = crate::join_force(dest_path, path);
                process_node(&path, node, false)?;
                next_node = node_streamer.next().transpose()?;
            }
        }
    }

    if additional_existing {
        warn!("Note: additional entries exist in destination");
    }

    restore_infos.stats = stats;
    restore_infos.root = dest_path.clone();
    p.finish();

    Ok(restore_infos)
}

/// Restore the metadata of the files and directories.
///
/// # Arguments
///
/// * `node_streamer` - The node streamer to use
/// * `opts` - The restore options to use
/// * `dest` - The destination to restore to
///
/// # Errors
///
/// * If the restore failed.
fn restore_metadata(
    mut node_streamer: impl Iterator<Item = RusticResult<(PathBuf, Node)>>,
    hardlink_candidates: &BTreeMap<HardlinkKey, PathBuf>,
    opts: RestoreOptions,
    dest: &impl WriteSource,
    token: CancelToken,
) -> RusticResult<()> {
    let mut dir_stack: Vec<(PathBuf, Node)> = Vec::new();
    while let Some((path, node)) = node_streamer.next().transpose()? {
        token.check()?;

        if dest.can_hard_link() {
            // Create hardlink directly, if this is one.
            if let Some(key) = hardlink_key(&node)
                && let Some(canonical) = hardlink_candidates.get(&key)
                && canonical != &path
            {
                debug!(
                    "restoring hardlink {} -> {}",
                    path.display(),
                    canonical.display()
                );
                dest.hard_link(canonical, &path).map_err(|err| {
                    RusticError::with_source(
                        ErrorKind::InputOutput,
                        "Failed to recreate the hardlink `{path}` from `{canonical}`.",
                        err,
                    )
                    .attach_context("path", path.display().to_string())
                    .attach_context("canonical", canonical.display().to_string())
                })?;
            }
        }

        match node.node_type {
            NodeType::Dir => {
                // set metadata for all non-parent paths in stack
                while let Some((stackpath, _)) = dir_stack.last() {
                    if path.starts_with(stackpath) {
                        break;
                    }
                    let (path, node) = dir_stack.pop().unwrap();
                    dest.set_restore_metadata(&path, &node, &opts)
                        .map_err(|err| {
                            RusticError::with_source(
                                ErrorKind::InputOutput,
                                "Failed to set metadata for `{path}`",
                                err,
                            )
                            .attach_context("path", path.display().to_string())
                        })?;
                }
                // push current path to the stack
                dir_stack.push((path, node));
            }
            _ => dest
                .set_restore_metadata(&path, &node, &opts)
                .map_err(|err| {
                    RusticError::with_source(
                        ErrorKind::InputOutput,
                        "Failed to set metadata for `{path}`",
                        err,
                    )
                    .attach_context("path", path.display().to_string())
                })?,
        }
    }

    // empty dir stack and set metadata
    for (path, node) in dir_stack.into_iter().rev() {
        dest.set_restore_metadata(&path, &node, &opts)
            .map_err(|err| {
                RusticError::with_source(
                    ErrorKind::InputOutput,
                    "Failed to set metadata for `{path}`",
                    err,
                )
                .attach_context("path", path.display().to_string())
            })?;
    }

    Ok(())
}

fn hardlink_key(node: &Node) -> Option<HardlinkKey> {
    (matches!(node.node_type, NodeType::File)
        && node.meta.links > 1
        && node.meta.device_id != 0
        && node.meta.inode != 0)
        .then_some(HardlinkKey {
            device_id: node.meta.device_id,
            inode: node.meta.inode,
        })
}

struct PackInfo {
    pack_id: PackId,
    from_file: Option<(usize, u64, u32)>,
    locations: BlobLocations<SmallVec<[(usize, u64); 1]>>,
}

impl PackInfo {
    #[allow(clippy::result_large_err)]
    /// coalesce two `PackInfo` if possible
    fn coalesce(self, other: Self) -> Result<Self, (Self, Self)> {
        if self.pack_id == other.pack_id // if the pack is identical
            && self.from_file.is_none() // and we don't read from a present file
            // and the blobs can be coalesced
            && self.locations.can_coalesce(&other.locations)
        {
            Ok(Self {
                pack_id: self.pack_id,
                from_file: self.from_file,
                locations: self.locations.append(other.locations),
            })
        } else {
            Err((self, other))
        }
    }
}

struct AppendState {
    cursor: u64,
    handle: Option<Box<dyn WriteHandle>>,
}
#[allow(clippy::too_many_lines)]
fn restore_contents<S: Open>(
    repo: &Repository<S>,
    dest: &impl WriteSource,
    filenames: &Filenames,
    file_lengths: Vec<u64>,
    restore_info: RestoreInfo,
    restore_size: u64,
    token: CancelToken,
) -> RusticResult<()> {
    token.check()?;

    let be = repo.dbe();
    let _num_files = file_lengths.len();

    // For random-write: create empty files now; non-empty files
    // are lazily allocated on first write via the sizes mutex.
    // For append: truncate ALL files to 0 now so appends start from a clean
    // slate (no stale content, no pre-allocated zeros causing over-length output).
    for (i, size) in file_lengths.iter().enumerate() {
        if *size == 0 {
            let path = &filenames[i];
            path.parent()
                .map(|parent| dest.create_dir_all(parent))
                .unwrap_or(Ok(()))
                .and_then(|_| dest.set_length(path, 0))
                .map_err(|err| {
                    RusticError::with_source(
                        ErrorKind::InputOutput,
                        "Failed to prepare the file `{path}`. Please check the path and try again.",
                        err,
                    )
                    .attach_context("path", path.display().to_string())
                })?;
        }
    }

    // Random-write path: tracks which files still need to be allocated
    // (set to their full size) before the first write_at.
    let sizes = &Mutex::new(file_lengths);

    let can_random_write = dest.can_random_write();

    // Cap on unwritten, buffered bytes per file for the append path. A
    // bounded channel gives real backpressure: if a file's writer thread
    // falls behind, the rayon worker trying to send it a chunk blocks —
    // but it blocks on an independent OS thread that is never itself
    // waiting on rayon, so this can't recreate the pool self-deadlock.
    // Keeps peak buffered memory roughly bounded instead of growing with
    // however much reordering happens to occur.
    const APPEND_CHANNEL_CAPACITY: usize = 16;

    let p = repo.progress_bytes("restoring file contents...");
    p.set_length(restore_size);
    let p = &p;

    // Borrow the token so rayon scoped closures can reference it without
    // moving it — the scope guarantees all threads finish before we return.
    let token = &token;

    let packs: Vec<_> = restore_info
        .into_iter()
        .map(|((pack_id, bl), fls)| {
            let from_file = fls
                .iter()
                .find(|fl| fl.matches)
                .map(|fl| (fl.file_idx, fl.file_start, bl.data_length()));

            let name_dests = fls
                .iter()
                .filter(|fl| !fl.matches)
                .map(|fl| (fl.file_idx, fl.file_start))
                .collect();

            PackInfo {
                pack_id,
                from_file,
                locations: BlobLocations::from_blob_location(bl, name_dests),
            }
        })
        .coalesce(PackInfo::coalesce)
        .collect();

    let threads = constants::MAX_READER_THREADS_NUM;
    let pool = ThreadPoolBuilder::new()
        .num_threads(threads)
        .build()
        .map_err(|err| {
            RusticError::with_source(
                ErrorKind::Internal,
                "Failed to create the thread pool with `{num_threads}` threads. Please try again.",
                err,
            )
            .attach_context("num_threads", threads.to_string())
        })?;

    // Append-only destinations require writes to land in strictly
    // increasing offset order per file. Previously that ordering was
    // enforced by blocking the *rayon worker itself* on a condvar until
    // an earlier chunk showed up — but that earlier chunk's write task
    // could itself be queued behind the block, in the same fixed-size
    // pool, with no free worker left to run it. Past a certain amount of
    // reordering, every worker ends up parked and the whole restore
    // wedges. This is the ONLY thing being changed: rayon's pool, its
    // size, and the random-write path below are untouched.
    //
    // Fix: writes for append destinations happen on real OS threads
    // (spawned via `std::thread::scope`), one per file that needs
    // ordered appending, entirely outside the rayon pool. Rayon workers
    // just decode a blob and `send` it down a bounded channel — never
    // blocking on other rayon tasks, so there's nothing left to
    // deadlock. Each writer thread owns the file's write handle and a
    // small out-of-order buffer, flushing whatever's contiguous as it
    // arrives, and closes the handle once its channel disconnects.
    std::thread::scope(|writer_scope| -> RusticResult<()> {
        let writers: Mutex<HashMap<usize, std::sync::mpsc::SyncSender<(u64, Bytes)>>> =
            Mutex::new(HashMap::new());
        let writers = &writers;

        pool.in_place_scope(|s| {
            for PackInfo {
                pack_id,
                from_file,
                locations:
                    BlobLocations {
                        offset,
                        length,
                        blobs,
                    },
            } in packs
            {
                if blobs.is_empty() {
                    continue;
                }
                // Stop dispatching new pack reads once cancelled. Already-queued
                // rayon tasks will still run (rayon doesn't support cancellation),
                // but they each check the token themselves and exit immediately.
                if token.is_cancelled() {
                    break;
                }
                s.spawn(move |s1| {
                    if token.is_cancelled() {
                        return;
                    }

                    let read_data = match (can_random_write, &from_file) {
                        (true, Some((file_idx, offset_file, length_file))) => {
                            let length: u64 = (*length_file).into();
                            let offset: u64 = *offset_file;
                            let path = &filenames[*file_idx];
                            let mut buf = vec![0; length as usize];
                            let mut file = dest.open_read(path).unwrap();
                            let _ = file.seek(SeekFrom::Start(offset)).unwrap();
                            file.read_exact(&mut buf).unwrap();
                            Bytes::from(buf)
                        }
                        _ => be
                            .read_partial(FileType::Pack, &pack_id, false, offset, length)
                            .unwrap(),
                    };

                    for (bl, name_dests) in blobs {
                        if token.is_cancelled() {
                            return;
                        }

                        let size: u64 = bl.data_length().into();
                        let data = if can_random_write && from_file.is_some() {
                            read_data.clone()
                        } else {
                            let start = usize::try_from(bl.offset - offset)
                                .expect("bl.offset - offset overflows usize");
                            let end = usize::try_from(bl.offset + bl.length - offset)
                                .expect("bl.offset + bl.length - offset overflows usize");
                            be.read_encrypted_from_partial(
                                &read_data[start..end],
                                bl.uncompressed_length,
                            )
                            .unwrap()
                        };

                        for (file_idx, start) in name_dests {
                            if token.is_cancelled() {
                                return;
                            }

                            let data = data.clone();

                            if can_random_write {
                                // Unchanged: identical to the original code path,
                                // same mutex, same write_at, same per-chunk spawn.
                                s1.spawn(move |_| {
                                    if token.is_cancelled() {
                                        return;
                                    }

                                    let path = &filenames[file_idx];
                                    // Lazily allocate the file to its full size on the first write.
                                    let mut sizes_guard = sizes.lock().unwrap();
                                    let filesize = sizes_guard[file_idx];
                                    if filesize > 0 {
                                        if let Some(parent) = path.parent() {
                                            dest.create_dir_all(parent).unwrap();
                                        }
                                        dest.set_length(path, filesize).unwrap();
                                        sizes_guard[file_idx] = 0;
                                    }
                                    drop(sizes_guard);
                                    dest.write_at(path, start, &data).unwrap();
                                    p.inc(size);
                                });
                            } else {
                                // Append path: hand the chunk off to (or spawn) this
                                // file's dedicated writer thread. `send` on a
                                // SyncSender blocks once the channel is full — that's
                                // fine here since it blocks this rayon worker only on
                                // an independent OS thread that always keeps draining,
                                // never on another rayon task.
                                let tx = {
                                    let mut guard = writers.lock().unwrap();
                                    guard
                                        .entry(file_idx)
                                        .or_insert_with(|| {
                                            let (tx, rx) =
                                                std::sync::mpsc::sync_channel::<(u64, Bytes)>(
                                                    APPEND_CHANNEL_CAPACITY,
                                                );
                                            let path = &filenames[file_idx];
                                            writer_scope.spawn(move || {
                                                let mut cursor: u64 = 0;
                                                let mut pending: BTreeMap<u64, Bytes> =
                                                    BTreeMap::new();
                                                let mut handle: Option<Box<dyn WriteHandle>> = None;

                                                while let Ok((start, chunk)) = rx.recv() {
                                                    pending.insert(start, chunk);
                                                    // Flush every chunk that's now contiguous
                                                    // with what we've already written. Chunks
                                                    // may arrive out of order (different rayon
                                                    // workers, different packs), so we only
                                                    // write what's actually next.
                                                    while let Some(chunk) = pending.remove(&cursor)
                                                    {
                                                        let h = handle.get_or_insert_with(|| {
                                                            debug!(
                                                                "Opening write handle to {:?}",
                                                                path
                                                            );
                                                            dest.open_replace(path).unwrap()
                                                        });
                                                        let len = chunk.len() as u64;
                                                        h.write_all(&chunk).unwrap();
                                                        cursor += len;
                                                        p.inc(len);
                                                    }
                                                }

                                                if let Some(mut h) = handle {
                                                    h.flush().unwrap();
                                                    if h.close().is_err() {
                                                        warn!(
                                                            "Failed to close file handle for {:?}.",
                                                            path
                                                        );
                                                    }
                                                }
                                            });
                                            tx
                                        })
                                        .clone()
                                };
                                // If the writer thread already exited (e.g. it hit an
                                // internal error), drop the chunk rather than panicking
                                // this rayon worker.
                                let _ = tx.send((start, data));
                            }
                        }
                    }
                });
            }
        });

        // `writers` drops here, closing every channel so each writer
        // thread finishes flushing + closes its handle; `thread::scope`
        // then joins all of them before returning.
        Ok(())
    })?;

    p.finish();
    Ok(())
}

/// Information about what will be restored.
///
/// Struct that contains information of file contents grouped by
/// 1) pack ID,
/// 2) blob within this pack
/// 3) the actual files and position of this blob within those
/// 4) Statistical information
#[derive(Debug, Default)]
pub struct RestorePlan {
    /// The root to restore from.
    root: PathBuf,
    /// The names of the files to restore
    names: Filenames,
    /// The length of the files to restore
    file_lengths: Vec<u64>,
    /// The restore information
    r: RestoreInfo,
    /// candidates for hardlinks
    hardlink_candidates: BTreeMap<HardlinkKey, PathBuf>,
    /// The total restore size
    pub restore_size: u64,
    /// The total size of matched content, i.e. content with needs no restore.
    pub matched_size: u64,
    /// Statistics about the restore.
    pub stats: RestoreStats,
}

/// [`FileLocation`] contains information about a file within a blob
#[derive(Debug)]
struct FileLocation {
    // TODO: The index of the file within ... ?
    file_idx: usize,
    /// The start of the file within the blob
    file_start: u64,
    /// Whether the file matches the blob
    ///
    /// This indicates that the file exists and these contents are already correct.
    matches: bool,
}

/// [`AddFileResult`] indicates the result of adding a file to [`FileLocation`]
// TODO: Add documentation!
enum AddFileResult {
    Existing,
    Verified,
    Modify,
}

impl RestorePlan {
    /// Add the file to [`FileLocation`] using `index` to get blob information.
    ///
    /// # Type Parameters
    ///
    /// * `P` - The progress bar type.
    /// * `S` - The type of the indexed tree.
    ///
    /// # Arguments
    ///
    /// * `dest` - The destination to restore to.
    /// * `file` - The file to add.
    /// * `name` - The name of the file.
    /// * `repo` - The repository to restore.
    /// * `ignore_mtime` - If true, ignore the modification time of the file.
    /// * `no_compare` - If true, do not scan the source files.
    ///
    /// # Errors
    ///
    /// * If the file could not be added.
    fn add_file<S: IndexedFull>(
        &mut self,
        dest: &impl WriteSource,
        file: &Node,
        name: PathBuf,
        repo: &Repository<S>,
        ignore_mtime: bool,
        no_read: bool,
    ) -> RusticResult<AddFileResult> {
        let existing_file = dest
            .stat(&name)
            .map_err(|err| {
                RusticError::with_source(ErrorKind::Backend, "Failed to lookup file `{path}`", err)
                    .attach_context("path", name.display().to_string())
            })?
            .filter(|meta| meta.size == file.meta.size);

        // Empty files which exists with correct size should always return Ok(Existing)!
        if file.meta.size == 0 && existing_file.is_some() {
            return Ok(AddFileResult::Existing);
        }

        if !ignore_mtime {
            if let Some(ref meta) = existing_file {
                if meta.size == file.meta.size && meta.mtime == file.meta.mtime {
                    // File exists with fitting mtime => we suspect this file is ok!
                    debug!(
                        "file {} exists with suitable size and mtime, accepting it!",
                        name.display()
                    );
                    self.matched_size += file.meta.size;
                    return Ok(AddFileResult::Existing);
                }
            }
        }

        // If no_read is set, we never read the destination's content - some object
        // storages charge enough for downloads that it's cheaper to just re-upload.
        // In that case every blob below is treated as unverified; the mtime check
        // above is the only way this file can come back as Existing/Verified.
        let mut open = if !no_read && existing_file.is_some() {
            Some(dest.open_read(&name).map_err(|err| {
                RusticError::with_source(
                    ErrorKind::Backend,
                    "Failed to open `{path}` for reading.",
                    err,
                )
                .attach_context("path", name.display().to_string())
            })?)
        } else {
            None
        };

        let file_idx = self.names.len();
        self.names.push(name.clone());
        let mut file_pos: u64 = 0;
        let mut has_unmatched = false;
        let mut matched_size = 0;
        let mut restore_size = 0;

        // On append-only destinations, one mismatch means the whole file gets
        // replaced, so any blobs already marked "matched" need flipping. We
        // remember them here just in case; this stays empty (and unused) on
        // random-write destinations, and gets drained+cleared the moment the
        // first mismatch is found, so it's never a second full pass.
        let mut tentatively_matched = Vec::new();

        for id in file.content.iter().flatten() {
            let ie = repo.get_index_entry(id)?;
            let bl = ie.location;
            let length: u64 = bl.data_length().into();
            let key = (ie.pack, bl);

            // Append-only backends (like OpenDAL) only allow a whole file replacement.
            // As a result, we can skip reading from `dest` as soon as we know the file
            // is different - since it needs to get replaced anyway.
            let should_read = !has_unmatched || dest.can_random_write();
            let matches = should_read
                && open
                    .as_mut()
                    .is_some_and(|open| id.blob_matches_reader(length, open));

            if matches {
                matched_size += length;
                if !dest.can_random_write() {
                    tentatively_matched.push((key.clone(), length));
                }
            } else {
                if !has_unmatched && !dest.can_random_write() {
                    // First mismatch on an append-only destination: flip
                    // everything we tentatively counted as matched so far.
                    for (k, len) in tentatively_matched.drain(..) {
                        if let Some(last) = self.r.get_mut(&k).and_then(|v| v.last_mut()) {
                            last.matches = false;
                        }
                        matched_size -= len;
                        restore_size += len;
                    }
                }
                restore_size += length;
                has_unmatched = true;
            }

            self.r.entry(key).or_default().push(FileLocation {
                file_idx,
                file_start: file_pos,
                matches,
            });

            file_pos += length;
        }

        self.restore_size += restore_size;
        self.matched_size += matched_size;
        self.file_lengths.push(file_pos);

        if !has_unmatched && existing_file.is_some() {
            Ok(AddFileResult::Verified)
        } else {
            Ok(AddFileResult::Modify)
        }
    }

    /// Get a list of all pack files needed to perform the restore
    ///
    /// This can be used e.g. to warm-up those pack files before doing the actual restore.
    #[must_use]
    pub fn to_packs(&self) -> Vec<PackId> {
        self.r
            .iter()
            // filter out packs which we need
            .filter(|(_, fls)| fls.iter().all(|fl| !fl.matches))
            .map(|((pack, _), _)| *pack)
            .dedup()
            .collect()
    }
}
