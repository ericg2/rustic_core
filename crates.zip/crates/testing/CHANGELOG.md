# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.1](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.4.0...rustic_testing-v0.4.1) - 2026-03-04

### Added

- Add methods for repairing hot/cold repositories ([#255](https://github.com/rustic-rs/rustic_core/pull/255))

### Other

- update dependencies ([#486](https://github.com/rustic-rs/rustic_core/pull/486))

## [0.4.0](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.3.4...rustic_testing-v0.4.0) - 2026-02-09

### Added

- [**breaking**] Add support for batch warmup ([#438](https://github.com/rustic-rs/rustic_core/pull/438))

## [0.3.4](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.3.3...rustic_testing-v0.3.4) - 2025-11-08

### Other

- update Cargo.toml dependencies

## [0.3.3](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.3.2...rustic_testing-v0.3.3) - 2025-09-12

### Other

- update to 2024 edition and fix clippy lints (#399)
- update dependencies and fix clippy lints / remove opendal::ftp support (#405)

## [0.3.2](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.3.1...rustic_testing-v0.3.2) - 2024-11-27

### Other

- update Cargo.toml dependencies

## [0.3.1](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.3.0...rustic_testing-v0.3.1) - 2024-11-24

### Other

- Revert "feat(async): add `async_compatible` methods to identify backend compatibility ([#355](https://github.com/rustic-rs/rustic_core/pull/355))"

## [0.3.0](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.2.3...rustic_testing-v0.3.0) - 2024-11-18

### Added

- *(async)* add `async_compatible` methods to identify backend compatibility ([#355](https://github.com/rustic-rs/rustic_core/pull/355))

### Other

- *(errors)* [**breaking**] Improve error handling, display and clean up codebase ([#321](https://github.com/rustic-rs/rustic_core/pull/321))

## [0.2.3](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.2.2...rustic_testing-v0.2.3) - 2024-10-25

### Other

- *(deps)* remove unused dependency once_cell ([#341](https://github.com/rustic-rs/rustic_core/pull/341))

## [0.2.2](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.2.1...rustic_testing-v0.2.2) - 2024-10-02

### Other

- *(deps)* update dependencies ([#292](https://github.com/rustic-rs/rustic_core/pull/292))

## [0.2.1](https://github.com/rustic-rs/rustic_core/compare/rustic_testing-v0.2.0...rustic_testing-v0.2.1) - 2024-09-06

### Fixed
- dprint

### Other
- use rustic_core from workspace
